# -*- coding: utf-8 -*-

__version__ = "10.4.1"

if __name__ == "__main__":
    print(__version__)
